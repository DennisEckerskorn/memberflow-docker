import React from 'react';

const TeacherDashboard = () => {
  return <h2>Welcome to the Teacher Dashboard</h2>;
};

export default TeacherDashboard;
