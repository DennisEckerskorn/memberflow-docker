import React from 'react';

const StudentDashboard = () => {
  return <h2>Welcome to the Student Dashboard</h2>;
};

export default StudentDashboard;
